# BlackWidow

Web crawler for [HeelsFetishism](http://heelsfetishism.com/)


## Install

``` bash
$ sudo apt-get install python-dev libxml2-dev libxslt1-dev
$ pip install -r requirements.txt
```


## Usage

``` bash
$ scrapy crawl atlanticpacific
$ scrapy crawl beautylegmm
$ scrapy crawl fancy
$ scrapy crawl garypeppergirl
$ scrapy crawl itscamilleco
$ scrapy crawl madamejulietta
$ scrapy crawl ohmyvogue
$ scrapy crawl pinterest
$ scrapy crawl sayhellomax
$ scrapy crawl tvcclub
$ scrapy crawl wendyslookbook
```


[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/vinta/blackwidow/trend.png)](https://bitdeli.com/free "Bitdeli Badge")
