# ChatServer-in-Intranet
If you are using an intranet network and have no means to communicate, use this python code to make a server where clients in the same network can chat.

The `Nchat_server.py` should be run on a server terminal with a room id. This will be used as communication hub between clients. 


The `Nchat_client.py` can be run by any individual on a terminal to choose an avatar name and start chatting on a server room id. Multiple people can be hosted on a single room. 


This is a pet project of me and Samvram Sahu. 
