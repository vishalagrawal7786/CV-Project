#!/bin/bash

pip install -r requirements.txt

echo 'I am alive!'
tail -f /dev/null
