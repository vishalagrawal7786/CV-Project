package ws.vinta.albedo

class AlbedoTest {

}