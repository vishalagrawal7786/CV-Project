# amazon-price-tracker

This project solves the tedious task of tracking the products in E-commerce gaint Amazon. 

All we need is product url and that's it.

This will notify the user when 
- The product becomes available
- Whenever there is price drop

This is work in progress.

