# BhoonidhiAPI
Creator: Rohit Gandikota 

Design and Developement of Python library and API: Rohit Gandikota

Design of backend API: Bhoonidhi API Team, NRSC. (Rohit Gandikota, Ankita Reddy, Richa Goyal)

New updates
1. Different end points based on search criteria
2. A new quick explore functionality to check the archival details of bhoondihi
3. New Error handling methods for many cases like query syntax error, archival error, server error, etc.
4. Query filter to check for any errors and security errors
5. With get_full_meta_info functionality
6. Batch_download functionality with automatic handling of concurrent downloads
7. Additional checksum error checks added for future use
8. Functionality for triggering Offline products
9. Filter on bhoonidhi response 
10. Functionality to convert output AOI to geojson, geodata frame from pandas, wkt etc. And an option to convert input AOI to any desired format.

The code follows universal python api standards (inspired from open-sourced 'sentinelsat api') and is well written with comments and descriptions where ever required.

Additional utilities are provided and commented to keep the code future proof.


