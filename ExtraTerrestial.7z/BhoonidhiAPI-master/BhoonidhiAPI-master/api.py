# -*- coding: utf-8 -*-
"""
Created on Thu Dec 17 11:02:13 2020

@author: rohit
"""

import flask
import requests
import dateutil
import datetime
import cx_Oracle
import re
app = flask.Flask(__name__)
app.config["DEBUG"] = False

def _url(endpoint):
    return f'https://bhoonidhi.nrsc.gov.in/bhoonidhi/{endpoint}'
def getBhoonidhiDates(string):
    terms = string.split(' ')
    date = terms[0]
    month = terms[1][:3].upper()
    year = terms[2]
    return month+'%2F'+date+'%2F'+year
def hitBhoonidhi(url,jsons):
    output = {}
    i=0
    for j in jsons.keys():
        i=i+1
        response = requests.post(url, json=jsons[j], timeout=30)
        try:
            if response.status_code == 200:
                if i == 1:
                    output[i] = response.json()['Results']
                else:
                    output[i] = (response.json()['Results'])
            else:
                {f'Error in Bhoonidhi with status code: {response.status_code}'}
        except:
            {'No Results Found'}
    return output
def getAvailableSatSen():
    ip = '172.19.2.16'
    port = 1521
    SID = 'UOPS'
    try:
        dsn_tns = cx_Oracle.makedsn(ip, port, SID)
        
        db = cx_Oracle.connect('uops', 'admin123', dsn_tns)
        c = db.cursor()
        c.execute('select * from  bhoonidhi_satsen_config') # use triple quotes if you want to spread your query across multiple lines
    except:
        raise Exception('Database Error at SatSen Configuration')
    satsen = []
    for row in c:
        satsen.append(row)
      
    return (satsen)
def getPID(pid):
    if pid.startswith('L') or pid.startswith('l'):
#        pid = 'L8O20DEC2020000000001360038PSANSTUC00GTDF'
        sat = 'LandSat-8'
        sen = 'OLI+TIRS'
        ptp='STANDARD'
        sdate = getBhoonidhiDates(dateutil.parser.parse(pid[3:12]).strftime("%d %B, %Y"))
        edate = sdate
    elif pid.startswith('S') or pid.startswith('s'):
       # pid = 'SEN2A_MSI_zzz_21DEC2020_119_zzz_zzz_zzz_zzz_zzz_001_S_ESA_STUBTAOJD_T44QMF'
       # SEN2A_MSI_zzz_21DEC2020_119_zzz_zzz_zzz_zzz_zzz_001_S_ESA_STUBBAOJD_T44PMV
       sat = pid.split('_')[0]
       sen = pid.split('_')[1]
       if re.search('zz',pid.split('_')[2]) or re.search('ZZ',pid.split('_')[2]):
           pass
       else:
           sen = sen+'('+ pid.split('_')[2]+')'
       if pid.split('_')[-2][4] == 'T':
           ptp='Level-1C'
       elif pid.split('_')[-2][4] == 'B':
           ptp= 'Level-2A'
       elif pid.split('_')[-2][4] == '0':
           ptp= 'GRD'
           
       sdate = getBhoonidhiDates(dateutil.parser.parse( pid.split('_')[3]).strftime("%d %B, %Y"))
       edate = sdate 
    elif pid.startswith('O') or pid.startswith('o'):
#         pid = 'O2_21DEC2020_001_011_GAN_L1B_ST_S'
        sat = 'OceanSat-2'
        sen = 'OCM'
        ptp = pid.split('_')[5]
        sdate = getBhoonidhiDates(dateutil.parser.parse( pid.split('_')[1]).strftime("%d %B, %Y"))
        edate = sdate
    else:
        return 0
    url = _url('ProductSearch')
    json = {}
    json = {"userId":"T","sat":sat,"sen":(sen).replace('+','%2B'),"searchCritera":"SatelliteBased","prod":ptp,"sdate":sdate,"edate":edate,"cloudThresh":str(100),"query":"date"}
    jsons = {}
    jsons['1']=json
    
    results = hitBhoonidhi(url,jsons)[1]
    for result in results:
        if result['OTS_OTSPRODUCTID'] == pid:
            return result
        else:
            return 0
@app.route('/', methods=['GET'])
def home():
    return "<h1>Bhoonidhi - ISRO's Open Data Hub</h1><p>This site is a prototype API for Bhoonidhi. <br> /GetSatellites/ <br>  /GetToken/ <br> /GetProductMeta/ <br> /GetProductUrl/ <br> /GetProducts/  <br> /GetProducts/ProductID/ <br> /GetProducts/Satellite/ </p>"
@app.route('/GetSatellites/', methods=['GET'])
def getSatellites():
    #url = http://172.31.3.93:5000/GetSatellites?slk=landsat&ptp=standard
    try:
        results = getAvailableSatSen()
    except Exception:
        return {'Results':'Error at Bhoonidhi Backend'}
    slk = flask.request.args.get('slk',default='')
    rsm =  flask.request.args.get('rsm',default=0.1)
    rsx =  flask.request.args.get('rsx',default=360)
    ptp = flask.request.args.get('ptp',default='')
    sdate =  flask.request.args.get('sdt',default='')
    edate =  flask.request.args.get('edt',default='')
    curated = []
    if slk != '':
        for result in results:
#            print(result[3])
            if slk.lower() in result[0].lower():
                curated.append(result)
    else:
        curated = results
#    rsm = float(rsm)
#    rsx = float(rsx)
    curated_new = []
    for result in curated:
        if result[3]>rsm and result[3]<rsx:
            curated_new.append(result)
    curated = curated_new
    curated_new = []
    if ptp !='':
        for result in curated:
            if ptp.lower() in result[6].lower():
                curated_new.append(result)
        curated = curated_new
        curated_new = []
    if sdate!='' and edate!='':
        sdate = dateutil.parser.parse(sdate, dayfirst=True)
        edate = dateutil.parser.parse(edate, dayfirst=True)
        for result in curated:
            if result[4]<sdate and result[5]>edate:
                curated_new.append(result)
            
        curated = curated_new
    results = [] 
    for result in curated:
        json = {}
        json['satellite']=result[0]
        json['sensor']=result[1]
        json['resolution']=result[3]
        json['imaging_mode']=result[2]
        json['product_code']=result[11]
        json['product_type']=result[6]
        json['start_date']=result[4]
        json['end_date']=result[5]
        results.append(json)
    return {'Results':results}
        
@app.route('/GetToken/', methods=['GET'])
def getToken():
    #url = http://172.31.3.93:5000/GetToken?usr=browse&pwd=browse
    def bhoonidhiLogin(user_id, password):
        url = 'https://bhoonidhi.nrsc.gov.in/bhoonidhi/LoginServlet'
        json = {}
        json['userId'] = user_id
        json['password'] = password
        json['oldDB'] = 'false'
        json['action'] = 'VALIDATE_LOGIN'
        
        response = requests.post(url, json=json)
        
        return response.json()["Results"][0]['JWT'], response.json()["Results"][0]['MSG'] 
    usr = flask.request.args.get('usr',default='')
    pwd =  flask.request.args.get('pwd',default='')
    if usr != '' and pwd!= '':
        token ={}
        token['token'],token['message'] = bhoonidhiLogin(usr, pwd)
        token['validity'] = 'NULL'
        
    else:
        token = {}
        token['token'] = 'NULL'
        token['validity']= 'NULL'
        token['message']='NO USERNAME AND PASSWORD ARE PROVIDED'
    return token
@app.route('/GetProductMeta/', methods=['GET'])
def getProductMeta():
    #url = http://172.31.3.93:5000/GetProductMeta?pid=L8O20DEC2020000000001360038PSANSTUC00GTDF
    pid = flask.request.args.get('pid',default='')
    if pid != '':
        product_obj = getPID(pid)
        sat = product_obj['OTS_SATELLITE']
        sen = product_obj['OTS_SENSOR']
        year = product_obj['OTS_DATE_OF_DUMPING'].split('-')[-1]
        month = product_obj['OTS_DATE_OF_DUMPING'].split('-')[1].upper()
        date = product_obj['OTS_DATE_OF_DUMPING'].split('-')[0].upper()
        prdId = product_obj['OTS_OTSPRODUCTID']
        url = "https://bhoonidhi.nrsc.gov.in/imgarchive/PRODUCTJPGS/" + sat + "/" + sen + "/" + year + "/" + month+ "/" + date + "/"+ prdId+".meta"
        meta_info = requests.get(url).text
        meta = {}
        lines = meta_info.splitlines()
        for line in lines:
            value = line.split('=')
            meta[value[0]]=value[-1]
        
        return {'Results':meta}
    else:
        return {'Results':"Error while fetching meta information. Product ID must to be provided"}


@app.route('/GetProductUrl/', methods=['GET'])
def getProductUrl():
    #url = http://172.31.3.93:5000/GetProducts/GetProductUrl?pid=L8O20DEC2020000000001360038PSANSTUC00GTDF&token=
    pid = flask.request.args.get('pid',default='')
    token = flask.request.args.get('token',default='')
    if pid != '' and token != '':
        product_obj = getPID(pid)
#        print(product_obj)
        sat = product_obj['OTS_SATELLITE']
        if sat == 'L8':
            sen = 'O'
        else:
             sen = product_obj['OTS_SENSOR']
        year = product_obj['OTS_DATE_OF_DUMPING'].split('-')[-1]
        month = product_obj['OTS_DATE_OF_DUMPING'].split('-')[1].upper()
        prdId = product_obj['OTS_OTSPRODUCTID']
        return {'downloadURL':"https://bhoonidhi.nrsc.gov.in/bhoonidhi/data/" + sat + "/" + sen + "/" + year + "/" + month + "/" + prdId + ".zip?token=" + token + "&product_id=" + prdId}
    else:
        return {'downloadURL':"Error while fetching download URL. Both Product ID and token must to be provided"}

@app.route('/GetProducts/', methods=['GET'])
def productsHome():
    return  "<h1>Get Products Functionality</h1><p>This URI is to get the products information through multiple ways. <br> /GetProducts/ProductID/ <br> /GetProducts/Satellite/</p>"

@app.route('/GetProducts/ProductID/', methods=['GET'])
def getProductsProductId():
    #url = http://172.31.3.93:5000/GetProducts/ProductID/L8O20DEC2020000000001360038PSANSTUC00GTDF
    pid =  flask.request.args.get('pid',default='')
    result = getPID(pid)
    if result == 0:    
        return {"Results Error":f"Could not find the product with product_id {pid}"}
    return result
@app.route('/GetProducts/Satellite/', methods=['GET'])
def getProductsSatellites():
    #URL = http://172.31.3.93:5000/GetProducts/Satellite?sat=Sentinel-2A&sen=MSI&ptp=Level-1C&sdate=01-01-2020&edate=01-03-2020 
    sat = flask.request.args.get('sat',default='LandSat-8')
    sen =  flask.request.args.get('sen',default='OLI+TIRS')
    img_mode = flask.request.args.get('sim',default='')
    if img_mode != '':
#        print(img_mode)
        img_mode ='-'+img_mode
    product_type =  flask.request.args.get('ptp',default='STANDARD')
    sdate =  flask.request.args.get('sdt',default=(datetime.datetime.now()-datetime.timedelta(days=20)).strftime('%d-%m-%y') )
    edate =  flask.request.args.get('edt',default=datetime.datetime.now().strftime('%d-%m-%y'))
    
    sdate = getBhoonidhiDates(dateutil.parser.parse(sdate, dayfirst=True).strftime("%d %B, %Y"))
    edate = getBhoonidhiDates(dateutil.parser.parse(edate, dayfirst=True).strftime("%d %B, %Y"))
    lat =  flask.request.args.get('lat',default='')
    lon =  flask.request.args.get('lon',default='')
    
    tllat = flask.request.args.get('tllat',default='')
    tllon =  flask.request.args.get('tllon',default='')
    trlat = flask.request.args.get('trlat',default='')
    trlon =  flask.request.args.get('trlon',default='')
    
    bllat = flask.request.args.get('bllat',default='')
    bllon =  flask.request.args.get('bllon',default='')
    brlat = flask.request.args.get('brlat',default='')
    brlon = flask.request.args.get('brlon',default='')
    
    pol=  flask.request.args.get('pol')
    path = (flask.request.args.get('pth'))
    row = (flask.request.args.get('row'))
    cloud = (flask.request.args.get('cld',default=100))
    sort_by_date =  flask.request.args.get('srt')
    offset = (flask.request.args.get('off'))
    limit = (flask.request.args.get('lim'))
    detailed = (flask.request.args.get('det'))
    
    url = _url('ProductSearch')
    json = {}
    json = {"userId":"T","sat":sat,"sen":(sen+img_mode).replace('+','%2B'),"searchCritera":"SatelliteBased","prod":product_type,"sdate":sdate,"edate":edate,"cloudThresh":str(cloud)}
    if tllat != '' and tllon != '' and brlat != '' and brlon != '':
        json.update({"query":"area","tllat":str(tllat),"tllon":str(tllon),"brlat":str(brlat),"brlon":str(brlon),"queryType":"polygon"})
    elif lat != '' and lon != '':
        json.update({"query":"area","lat":str(lat),"lon":str(lon),"radius":"10","queryType":"location"})
    else:
        json.update({"query":"date"})
    jsons = {}
    jsons['1']=json
    return (hitBhoonidhi(url,jsons))

app.run(host='172.31.3.93')